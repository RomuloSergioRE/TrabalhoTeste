package br.com.aula.exception;

public class ContaNaoExistenteException extends Exception {

	private static final long serialVersionUID = 1L;

}
